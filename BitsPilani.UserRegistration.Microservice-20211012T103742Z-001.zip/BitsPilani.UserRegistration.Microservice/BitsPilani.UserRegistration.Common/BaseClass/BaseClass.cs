﻿using AutoMapper;
using BitsPilani.UserRegistration.Common.Interfaces;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.UserRegistration.Common.BaseClass
{
    public class BaseClass
    {
        public IUnitOfWork UnitOfWork { get; set; }
        public IConfigConstants ConfigConstants { get; set; }
        public IMapper Mapper { get; set; }

        public BaseClass(IConfigConstants configConstants, IUnitOfWork unitOfWork, IMapper mapper)
        {
            ConfigConstants = configConstants;
            UnitOfWork = unitOfWork;
            Mapper = mapper;
        }
    }
}
