﻿using BitsPilani.UserRegistration.Common.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.Common.Repositories
{
    public interface IUserRegistrationRepository
    {
        Task<int> AddRegisteredUser(UserEntity user);
        Task<bool> UpdateRegisteredUser(UserEntity user);
        Task<bool> DeleteRegisteredUser(int userId);
        Task<IEnumerable<UserEntity>> GetAllRegisteredUsers();
        Task<UserEntity> GetRegisteredUser(long userId);
        Task<bool> DeleteAllRegisteredUser();
    }
}
