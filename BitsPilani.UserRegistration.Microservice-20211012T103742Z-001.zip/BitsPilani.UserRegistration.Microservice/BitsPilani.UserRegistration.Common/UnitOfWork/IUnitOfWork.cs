﻿using BitsPilani.UserRegistration.Common.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.UserRegistration.Common.UnitOfWork
{
    public interface IUnitOfWork
    {
        IUserRegistrationRepository Users { get; }
        void StartTransaction();
        void Commit();
    }
}
