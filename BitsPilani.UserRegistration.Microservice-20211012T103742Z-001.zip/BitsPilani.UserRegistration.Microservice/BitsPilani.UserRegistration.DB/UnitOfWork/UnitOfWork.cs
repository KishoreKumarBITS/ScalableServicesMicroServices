﻿using BitsPilani.UserRegistration.Common.Repositories;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using BitsPilani.UserRegistration.DB.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BitsPilani.UserRegistration.DB.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private IDbConnection dbConnection;
        private IDbTransaction transaction;
        public UnitOfWork(IDbConnection dbConnection)
        {
            this.dbConnection = dbConnection;
            this.ManageConnection();
        }
        public IUserRegistrationRepository Users => new UserRegistrationRepository(this.dbConnection, this.transaction);

        public void StartTransaction()
        {

            if (this.transaction == null)
            {
                this.transaction = this.dbConnection.BeginTransaction();
            }
        }
        public void Commit()
        {
            try
            {
                this.transaction.Commit();
            }
            catch
            {
                this.transaction.Rollback();
            }
        }

        private void ManageConnection()
        {
            if (this.dbConnection.State == ConnectionState.Closed)
            {
                this.dbConnection.Open();
            }
        }
    }
}
