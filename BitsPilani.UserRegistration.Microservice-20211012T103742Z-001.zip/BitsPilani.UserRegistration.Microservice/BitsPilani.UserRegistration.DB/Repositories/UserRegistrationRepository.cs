﻿using BitsPilani.UserRegistration.Common.Entities;
using BitsPilani.UserRegistration.Common.Repositories;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.DB.Repositories
{
    public class UserRegistrationRepository:Repository, IUserRegistrationRepository
    {
        public UserRegistrationRepository(IDbConnection dbConnection, IDbTransaction dbtransaction)
            : base(dbConnection, dbtransaction)
        {
        }
        public Task<int> AddRegisteredUser(UserEntity user)
        {
            user.DateAdded = DateTime.Now;
            user.DateUpdated = null;
            return DbConnection.InsertAsync(user, DbTransaction);
        }
        public Task<bool> DeleteRegisteredUser(int userId)
        {
            return DbConnection.DeleteAsync(new UserEntity { UserID = userId }, DbTransaction);
        }
        public Task<IEnumerable<UserEntity>> GetAllUsers()
        {
            return DbConnection.GetAllAsync<UserEntity>();
        }

        public Task<UserEntity> GetUser(long userId)
        {
            return DbConnection.GetAsync<UserEntity>(userId);
        }

        public Task<bool> UpdateRegisteredUser(UserEntity user)
        {
            user.DateUpdated = DateTime.Now;
            return DbConnection.UpdateAsync(user, DbTransaction);
        }

        public Task<bool> DeleteAllRegisteredUser()
        {
            return DbConnection.DeleteAllAsync<UserEntity>();
        }

        public Task<IEnumerable<UserEntity>> GetAllRegisteredUsers()
        {
            throw new NotImplementedException();
        }

        public Task<UserEntity> GetRegisteredUser(long userId)
        {
            throw new NotImplementedException();
        }

      
    }
}
