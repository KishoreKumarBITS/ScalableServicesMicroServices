﻿using AutoMapper;
using BitsPilani.UserRegistration.Common.BaseClass;
using BitsPilani.UserRegistration.Common.Exceptions;
using BitsPilani.UserRegistration.Common.Interfaces;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.BL.UserRegistration.Commands
{
    public class UpdateUserCommand : IRequest<bool>
    {
        public int UserID { get; set; }
        public string PhoneNumber { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
        public class UpdateUserHandler : BaseClass, IRequestHandler<UpdateUserCommand, bool>
        {
            public UpdateUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<bool> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
            {
                var user = await this.UnitOfWork.Users.GetRegisteredUser(request.UserID);
                if (user == null)
                {
                    throw new NotFoundException($"The User ID {request.UserID} is not found");
                }

                user.PhoneNumber = request.PhoneNumber;
                user.City = request.City;
                user.State = request.State;
                user.Zip = request.Zip;
                user.Country = request.Country;
                this.UnitOfWork.StartTransaction();
                var res = UnitOfWork.Users.UpdateRegisteredUser(user).Result;
                this.UnitOfWork.Commit();
                return await Task.Run(() => res, cancellationToken);
            }
        }
    }
}
