﻿using AutoMapper;
using BitsPilani.UserRegistration.BL.UserRegistration.UserRegistrationVM;
using BitsPilani.UserRegistration.Common.BaseClass;
using BitsPilani.UserRegistration.Common.Entities;
using BitsPilani.UserRegistration.Common.Interfaces;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.BL.UserRegistration.Commands
{
    public class AddUserCommand : IRequest<int>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
        public class AddNewUserHandler : BaseClass, IRequestHandler<AddUserCommand, int>
        {
            public AddNewUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<int> Handle(AddUserCommand request, CancellationToken cancellationToken)
            {
                var user = new UserEntity
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    DOB = request.DOB,
                    Gender = request.Gender.ToUpper(),
                    EmailAddress = request.EmailAddress,
                    PhoneNumber = request.PhoneNumber,
                    City = request.City,
                    State = request.State,
                    Zip = request.Zip,
                    Country = request.Country
                };
                this.UnitOfWork.StartTransaction();
                var res = UnitOfWork.Users.AddRegisteredUser(user).Result;
                this.UnitOfWork.Commit();
                return await Task.Run(() => res, cancellationToken);
            }
        }
    }
}
