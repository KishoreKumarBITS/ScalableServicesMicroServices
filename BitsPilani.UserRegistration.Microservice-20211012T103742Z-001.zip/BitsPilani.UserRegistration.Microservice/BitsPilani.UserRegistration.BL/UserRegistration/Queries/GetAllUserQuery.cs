﻿using AutoMapper;
using BitsPilani.UserRegistration.BL.UserRegistration.DTO;
using BitsPilani.UserRegistration.BL.UserRegistration.UserRegistrationVM;
using BitsPilani.UserRegistration.Common.BaseClass;
using BitsPilani.UserRegistration.Common.Interfaces;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.BL.UserRegistration.Queries
{
    public class GetAllUserQuery : IRequest<UserVM>
    {
        public class GetAllUserHandler : BaseClass, IRequestHandler<GetAllUserQuery, UserVM>
        {
            public GetAllUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<UserVM> Handle(GetAllUserQuery request, CancellationToken cancellationToken)
            {
                var res = Mapper.Map(UnitOfWork.Users.GetAllRegisteredUsers().Result, new List<UserRegistrationDTO>());
                return await Task.FromResult(new UserVM() { UserList = res });
            }
        }
    }
}
